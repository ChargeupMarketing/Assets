import "./globals.css";
import type { Metadata } from "next";

export const metadata: Metadata = {
  title: "Conversation Studio",
  description: "LinkedIn-first conversation intelligence and engagement copilot.",
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}
