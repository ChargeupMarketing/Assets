import Link from "next/link";

export default function HomePage() {
  return (
    <main className="flex min-h-screen items-center justify-center bg-slate-950 px-6 text-white">
      <div className="max-w-3xl text-center">
        <p className="mb-4 text-sm uppercase tracking-[0.25em] text-green-400">Conversation Studio</p>
        <h1 className="mb-6 text-5xl font-semibold tracking-tight">Discover conversations, trends, people, and AI-ready replies.</h1>
        <p className="mx-auto mb-8 max-w-2xl text-lg text-slate-300">
          A LinkedIn-first intelligence workspace for topic monitoring, people discovery, AI comment drafting, and response operations.
        </p>
        <div className="flex flex-wrap justify-center gap-4">
          <Link href="/app" className="rounded-2xl bg-green-500 px-6 py-3 font-medium text-slate-950">Open dashboard</Link>
          <Link href="/app/settings" className="rounded-2xl border border-slate-700 px-6 py-3 font-medium text-slate-200">View settings</Link>
        </div>
      </div>
    </main>
  );
}
