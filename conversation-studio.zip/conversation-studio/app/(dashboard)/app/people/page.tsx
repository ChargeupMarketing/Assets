import { DashboardShell } from "@/components/dashboard/shell";
import { people } from "@/lib/data/mock";

export default function PeoplePage() {
  return (
    <DashboardShell title="People Finder" description="Find relevant people surfaced from topic-matched posts and comments.">
      <div className="space-y-4">
        {people.map((person) => (
          <div key={person.id} className="rounded-3xl bg-white p-5 shadow-sm">
            <div className="flex flex-wrap items-center gap-3">
              <div>
                <div className="text-lg font-semibold">{person.name}</div>
                <div className="text-sm text-slate-500">{person.title}</div>
              </div>
              <div className="ml-auto rounded-full bg-green-100 px-3 py-1 text-sm text-green-700">{person.match}% match</div>
            </div>
            <p className="mt-3 text-sm text-slate-600">{person.reason}</p>
            <div className="mt-4 text-sm text-slate-500">{person.followers} followers</div>
          </div>
        ))}
      </div>
    </DashboardShell>
  );
}
