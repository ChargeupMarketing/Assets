import { DashboardShell } from "@/components/dashboard/shell";

export default function SettingsPage() {
  return (
    <DashboardShell title="Settings" description="Define your default tone, guardrails, and workspace preferences.">
      <div className="grid gap-6 lg:grid-cols-2">
        <div className="rounded-3xl bg-white p-5 shadow-sm">
          <h2 className="mb-4 text-lg font-semibold">Brand defaults</h2>
          <div className="space-y-4">
            <input className="w-full rounded-2xl border border-slate-200 px-4 py-3" defaultValue="Professional" />
            <textarea className="min-h-32 w-full rounded-2xl border border-slate-200 p-4" defaultValue="Avoid exaggerated claims, do not overpromise outcomes, keep tone informed and human." />
          </div>
        </div>
        <div className="rounded-3xl bg-white p-5 shadow-sm">
          <h2 className="mb-4 text-lg font-semibold">Connector status</h2>
          <div className="space-y-3 text-sm text-slate-600">
            <div>LinkedIn manual import: active</div>
            <div>LinkedIn connector: placeholder</div>
            <div>Direct reply action: feature flagged off</div>
          </div>
        </div>
      </div>
    </DashboardShell>
  );
}
