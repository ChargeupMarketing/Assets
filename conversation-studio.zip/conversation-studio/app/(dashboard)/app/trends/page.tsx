"use client";

import { DashboardShell } from "@/components/dashboard/shell";
import { keywordMomentum, trendData } from "@/lib/data/mock";
import { ResponsiveContainer, LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, BarChart, Bar } from "recharts";

export default function TrendsPage() {
  return (
    <DashboardShell title="Trend Explorer" description="Track post momentum, comment velocity, and rising keywords.">
      <div className="grid gap-6 xl:grid-cols-3">
        <div className="rounded-3xl bg-white p-5 shadow-sm xl:col-span-2">
          <h2 className="mb-4 text-lg font-semibold">Topic momentum</h2>
          <div className="h-80">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={trendData}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="day" />
                <YAxis />
                <Tooltip />
                <Line type="monotone" dataKey="posts" strokeWidth={3} />
                <Line type="monotone" dataKey="comments" strokeWidth={3} />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </div>
        <div className="rounded-3xl bg-white p-5 shadow-sm">
          <h2 className="mb-4 text-lg font-semibold">Rising keywords</h2>
          <div className="space-y-4">
            {keywordMomentum.map((item) => (
              <div key={item.keyword}>
                <div className="mb-1 flex justify-between text-sm"><span>{item.keyword}</span><span>{item.score}</span></div>
                <div className="h-2 rounded-full bg-slate-100"><div className="h-2 rounded-full bg-green-500" style={{ width: `${item.score}%` }} /></div>
              </div>
            ))}
          </div>
        </div>
      </div>
      <div className="mt-6 rounded-3xl bg-white p-5 shadow-sm">
        <h2 className="mb-4 text-lg font-semibold">Keyword leaderboard</h2>
        <div className="h-80">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={keywordMomentum} layout="vertical" margin={{ left: 30 }}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis type="number" />
              <YAxis type="category" dataKey="keyword" width={140} />
              <Tooltip />
              <Bar dataKey="score" radius={[0, 12, 12, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>
    </DashboardShell>
  );
}
