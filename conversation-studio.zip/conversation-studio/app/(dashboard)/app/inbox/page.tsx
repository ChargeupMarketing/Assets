import { DashboardShell } from "@/components/dashboard/shell";
import { feed } from "@/lib/data/mock";

export default function InboxPage() {
  return (
    <DashboardShell title="Inbox" description="All imported and discovered conversations in one place.">
      <div className="space-y-4">
        {feed.map((item) => (
          <div key={item.id} className="rounded-3xl bg-white p-5 shadow-sm">
            <div className="flex flex-wrap items-center gap-3">
              <div className="font-semibold">{item.author}</div>
              <div className="rounded-full bg-slate-100 px-3 py-1 text-xs">{item.topic}</div>
              <div className="ml-auto text-sm text-slate-500">{item.time}</div>
            </div>
            <div className="mt-3 text-sm text-slate-700">{item.post}</div>
            <div className="mt-3 rounded-2xl bg-slate-50 p-4 text-sm text-slate-700">{item.comment}</div>
          </div>
        ))}
      </div>
    </DashboardShell>
  );
}
