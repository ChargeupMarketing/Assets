"use client";

import { useMemo, useState } from "react";
import { DashboardShell } from "@/components/dashboard/shell";
import { feed, tones } from "@/lib/data/mock";

export default function ReviewPage() {
  const [tone, setTone] = useState("Professional");
  const [selectedId, setSelectedId] = useState(feed[0].id);
  const [draft, setDraft] = useState("Strong point. The next unlock is grounding EV lending decisions in real battery performance and fleet usage data, not assumptions.");
  const selected = useMemo(() => feed.find((item) => item.id === selectedId) ?? feed[0], [selectedId]);

  return (
    <DashboardShell title="Engage Copilot" description="Generate comments and replies with tone controls and action tracking.">
      <div className="grid gap-6 xl:grid-cols-12">
        <div className="rounded-3xl bg-white p-5 shadow-sm xl:col-span-4">
          <h2 className="mb-4 text-lg font-semibold">Queue</h2>
          <div className="space-y-3">
            {feed.map((item) => (
              <button key={item.id} onClick={() => setSelectedId(item.id)} className={`w-full rounded-2xl border p-4 text-left ${selectedId === item.id ? "border-green-200 bg-green-50" : "border-slate-200"}`}>
                <div className="font-medium">{item.author}</div>
                <div className="mt-1 text-sm text-slate-500">{item.comment}</div>
              </button>
            ))}
          </div>
        </div>
        <div className="rounded-3xl bg-white p-5 shadow-sm xl:col-span-8">
          <div className="mb-4 grid gap-4 md:grid-cols-2">
            <div>
              <div className="mb-2 text-sm font-medium">Tone preset</div>
              <select value={tone} onChange={(e) => setTone(e.target.value)} className="w-full rounded-2xl border border-slate-200 px-4 py-3">
                {tones.map((item) => <option key={item}>{item}</option>)}
              </select>
            </div>
            <div>
              <div className="mb-2 text-sm font-medium">Post URL</div>
              <input readOnly value={selected.postUrl} className="w-full rounded-2xl border border-slate-200 px-4 py-3 text-sm text-slate-500" />
            </div>
          </div>
          <div className="mb-4 rounded-2xl bg-slate-50 p-4 text-sm text-slate-700">{selected.post}</div>
          <div className="mb-4 rounded-2xl bg-amber-50 p-4 text-sm text-slate-700">{selected.comment}</div>
          <textarea value={draft} onChange={(e) => setDraft(e.target.value)} className="min-h-48 w-full rounded-2xl border border-slate-200 p-4" />
          <div className="mt-4 flex flex-wrap gap-3">
            <button className="rounded-2xl bg-green-500 px-5 py-3 font-medium text-slate-950">Generate 3 options</button>
            <button className="rounded-2xl border border-slate-200 px-5 py-3">Copy reply</button>
            <button className="rounded-2xl border border-slate-200 px-5 py-3">Open post URL</button>
          </div>
        </div>
      </div>
    </DashboardShell>
  );
}
