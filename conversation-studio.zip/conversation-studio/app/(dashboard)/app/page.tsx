import Link from "next/link";
import { DashboardShell } from "@/components/dashboard/shell";
import { feed } from "@/lib/data/mock";

export default function DashboardPage() {
  return (
    <DashboardShell title="Live Monitor" description="Topic-based conversation tracking and quick engagement actions.">
      <div className="grid gap-4 md:grid-cols-4">
        {[
          ["Live posts", "124"],
          ["Tracked comments", "482"],
          ["People to connect", "39"],
          ["AI-ready opportunities", "27"],
        ].map(([label, value]) => (
          <div key={label} className="rounded-3xl bg-white p-5 shadow-sm">
            <div className="text-sm text-slate-500">{label}</div>
            <div className="mt-2 text-3xl font-semibold">{value}</div>
          </div>
        ))}
      </div>

      <div className="mt-6 grid gap-6 xl:grid-cols-2">
        <div className="rounded-3xl bg-white p-5 shadow-sm">
          <div className="mb-4 flex items-center justify-between">
            <h2 className="text-lg font-semibold">Latest conversations</h2>
            <Link className="text-sm text-green-700" href="/app/review">Open engage copilot</Link>
          </div>
          <div className="space-y-4">
            {feed.map((item) => (
              <div key={item.id} className="rounded-2xl border border-slate-200 p-4">
                <div className="mb-2 text-sm font-semibold">{item.author}</div>
                <div className="mb-2 text-xs text-slate-500">{item.headline}</div>
                <div className="text-sm text-slate-700">{item.post}</div>
                <div className="mt-2 rounded-xl bg-slate-100 px-3 py-2 text-sm text-slate-700">“{item.comment}”</div>
              </div>
            ))}
          </div>
        </div>

        <div className="rounded-3xl bg-white p-5 shadow-sm">
          <h2 className="mb-4 text-lg font-semibold">Build notes</h2>
          <ul className="space-y-3 text-sm text-slate-600">
            <li>• This scaffold is wired for Next.js + Supabase + OpenAI.</li>
            <li>• API routes currently return mock data so you can host immediately.</li>
            <li>• Replace the mock layer with your LinkedIn connector or import workflow.</li>
            <li>• Use the SQL file in supabase/schema.sql to create tables.</li>
          </ul>
        </div>
      </div>
    </DashboardShell>
  );
}
