import { NextResponse } from "next/server";

export async function POST() {
  return NextResponse.json({ ok: true, action: "open_post_logged" });
}
