import { NextResponse } from "next/server";

export async function GET() {
  return NextResponse.json({ items: [{ id: "topic-1", name: "EV Financing" }, { id: "topic-2", name: "EV Tech" }] });
}

export async function POST(req: Request) {
  const body = await req.json();
  return NextResponse.json({ id: crypto.randomUUID(), ...body }, { status: 201 });
}
