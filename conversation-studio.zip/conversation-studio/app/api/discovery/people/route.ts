import { NextResponse } from "next/server";
import { people } from "@/lib/data/mock";

export async function GET() {
  return NextResponse.json({ items: people });
}
