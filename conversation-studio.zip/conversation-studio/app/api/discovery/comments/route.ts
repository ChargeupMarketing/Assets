import { NextResponse } from "next/server";
import { feed } from "@/lib/data/mock";

export async function GET() {
  return NextResponse.json({ items: feed.map((item) => ({
    id: item.id,
    authorName: item.author,
    commentText: item.comment,
    sentiment: "positive",
    topic: item.topic,
  })) });
}
