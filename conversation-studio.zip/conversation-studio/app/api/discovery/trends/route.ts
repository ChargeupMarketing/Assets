import { NextResponse } from "next/server";
import { keywordMomentum, trendData } from "@/lib/data/mock";

export async function GET() {
  return NextResponse.json({ trendData, keywordMomentum });
}
