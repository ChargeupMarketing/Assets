import { NextResponse } from "next/server";
import { feed } from "@/lib/data/mock";

export async function GET() {
  return NextResponse.json({ items: feed.map((item) => ({
    id: item.id,
    authorName: item.author,
    headline: item.headline,
    postUrl: item.postUrl,
    postText: item.post,
    publishedAt: new Date().toISOString(),
    engagementScore: 88.2,
    topicScore: 92.4,
  })) });
}
