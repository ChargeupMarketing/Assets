import { NextResponse } from "next/server";

export async function POST() {
  return NextResponse.json({
    draftId: crypto.randomUUID(),
    options: [
      "Strong point. The next unlock is grounding EV lending in actual battery performance data.",
      "Totally agree. Better underwriting starts when lenders can see asset health instead of guessing risk.",
      "This is the core issue. Confidence in EV credit grows when fleet usage and battery behavior become measurable.",
    ],
  });
}
