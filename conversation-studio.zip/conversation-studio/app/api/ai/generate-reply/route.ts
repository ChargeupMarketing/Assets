import { NextResponse } from "next/server";

export async function POST() {
  return NextResponse.json({
    draftId: crypto.randomUUID(),
    options: [
      "Well said. The lending gap often starts with missing confidence in battery-backed underwriting.",
      "Agreed. Better visibility into asset health can change how lenders look at EV risk.",
      "Exactly. Once lenders trust the data behind the asset, credit access improves for the driver too.",
    ],
  });
}
