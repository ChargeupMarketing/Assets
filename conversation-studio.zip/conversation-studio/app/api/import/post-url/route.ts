import { NextResponse } from "next/server";

export async function POST(req: Request) {
  const body = await req.json();
  return NextResponse.json({ id: crypto.randomUUID(), source: body.sourceName ?? "linkedin_manual", postUrl: body.postUrl }, { status: 201 });
}
