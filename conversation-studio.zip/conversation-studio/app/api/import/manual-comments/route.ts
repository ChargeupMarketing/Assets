import { NextResponse } from "next/server";

export async function POST(req: Request) {
  const body = await req.json();
  return NextResponse.json({ imported: Array.isArray(body.comments) ? body.comments.length : 0 }, { status: 201 });
}
