import Link from "next/link";
import { Activity, MessageSquare, TrendingUp, Users } from "lucide-react";

const items = [
  { href: "/app", label: "Live Monitor", icon: Activity },
  { href: "/app/trends", label: "Trend Explorer", icon: TrendingUp },
  { href: "/app/people", label: "People Finder", icon: Users },
  { href: "/app/review", label: "Engage Copilot", icon: MessageSquare },
];

export function Sidebar() {
  return (
    <aside className="w-full border-b bg-white p-4 lg:w-72 lg:border-b-0 lg:border-r">
      <div className="mb-6">
        <div className="text-lg font-semibold">Conversation Studio</div>
        <p className="text-sm text-slate-500">LinkedIn-first intelligence</p>
      </div>
      <nav className="space-y-2">
        {items.map((item) => {
          const Icon = item.icon;
          return (
            <Link key={item.href} href={item.href} className="flex items-center gap-3 rounded-2xl px-3 py-2 text-sm transition hover:bg-slate-100">
              <Icon className="h-4 w-4" />
              {item.label}
            </Link>
          );
        })}
      </nav>
    </aside>
  );
}
