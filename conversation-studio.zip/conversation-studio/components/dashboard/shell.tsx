import { Sidebar } from "@/components/layout/sidebar";

export function DashboardShell({ title, description, children }: { title: string; description: string; children: React.ReactNode }) {
  return (
    <div className="min-h-screen lg:flex">
      <Sidebar />
      <main className="flex-1">
        <header className="border-b bg-white px-6 py-5">
          <h1 className="text-2xl font-semibold">{title}</h1>
          <p className="mt-1 text-sm text-slate-500">{description}</p>
        </header>
        <div className="p-6">{children}</div>
      </main>
    </div>
  );
}
