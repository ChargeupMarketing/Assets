export function buildReplyPrompt(input: {
  topic: string;
  postText: string;
  commentText: string;
  tonePreset: string;
  lengthPref: string;
  ctaPref: string;
}) {
  return `You are drafting LinkedIn-ready replies.\nTopic: ${input.topic}\nTone: ${input.tonePreset}\nLength: ${input.lengthPref}\nCTA: ${input.ctaPref}\nPost: ${input.postText}\nComment: ${input.commentText}\nReturn 3 distinct reply options in JSON.`;
}
