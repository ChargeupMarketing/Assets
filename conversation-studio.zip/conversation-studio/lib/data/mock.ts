export type FeedItem = {
  id: string;
  author: string;
  headline: string;
  topic: string;
  keyword: string;
  platform: string;
  time: string;
  urgency: "High" | "Medium" | "Low";
  postUrl: string;
  post: string;
  comment: string;
};

export const trendData = [
  { day: "Mon", posts: 18, comments: 42 },
  { day: "Tue", posts: 22, comments: 51 },
  { day: "Wed", posts: 30, comments: 67 },
  { day: "Thu", posts: 28, comments: 61 },
  { day: "Fri", posts: 36, comments: 79 },
  { day: "Sat", posts: 24, comments: 44 },
  { day: "Sun", posts: 34, comments: 73 },
];

export const keywordMomentum = [
  { keyword: "battery financing", score: 92 },
  { keyword: "fleet electrification", score: 81 },
  { keyword: "driver income", score: 76 },
  { keyword: "swapping infra", score: 71 },
  { keyword: "EV credit risk", score: 66 },
];

export const feed: FeedItem[] = [
  {
    id: "1",
    author: "Ankit Verma",
    headline: "EV finance operator | 12k followers",
    topic: "EV Financing",
    keyword: "battery financing",
    platform: "LinkedIn",
    time: "2m ago",
    urgency: "High",
    postUrl: "https://linkedin.com/posts/example-1",
    post: "The missing layer in EV lending is not intent, it is confidence in battery-backed underwriting.",
    comment: "Exactly. Most lenders still do not understand real battery performance on the ground."
  },
  {
    id: "2",
    author: "Riya Kapoor",
    headline: "Clean mobility founder | 8.4k followers",
    topic: "EV Tech",
    keyword: "swapping infra",
    platform: "LinkedIn",
    time: "8m ago",
    urgency: "Medium",
    postUrl: "https://linkedin.com/posts/example-2",
    post: "Battery swapping only wins when uptime beats charging downtime in real fleet economics.",
    comment: "Would love to see more operators publish actual uptime data here."
  },
  {
    id: "3",
    author: "Priya Menon",
    headline: "Future of work writer | 21k followers",
    topic: "Gig Workers",
    keyword: "driver income",
    platform: "LinkedIn",
    time: "14m ago",
    urgency: "High",
    postUrl: "https://linkedin.com/posts/example-3",
    post: "The EV conversation is incomplete if we do not talk about driver earnings, asset risk, and replacement cycles.",
    comment: "This is the sharpest take I have read this week."
  },
];

export const people = [
  {
    id: "1",
    name: "Mohan Das",
    title: "EV Lending Strategist",
    match: 96,
    reason: "Posts weekly about EV underwriting, battery risk, and fleet finance.",
    followers: "14.2k",
  },
  {
    id: "2",
    name: "Sneha Rao",
    title: "Mobility Journalist",
    match: 89,
    reason: "Covers policy, financing, and startup signals around last-mile mobility.",
    followers: "32.5k",
  },
  {
    id: "3",
    name: "Arjun Malik",
    title: "Fleet Operations Leader",
    match: 84,
    reason: "High-comment, high-engagement practitioner perspective on utilization and uptime.",
    followers: "9.1k",
  },
];

export const tones = ["Professional", "Insightful", "Warm", "Bold", "Curious", "Brand-safe"];
