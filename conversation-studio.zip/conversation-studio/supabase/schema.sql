create extension if not exists pgcrypto;

create table workspaces (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  owner_user_id uuid not null,
  created_at timestamptz not null default now()
);

create table users_profile (
  id uuid primary key,
  workspace_id uuid references workspaces(id) on delete set null,
  name text,
  email text,
  created_at timestamptz not null default now()
);

create table topics (
  id uuid primary key default gen_random_uuid(),
  workspace_id uuid not null references workspaces(id) on delete cascade,
  name text not null,
  description text,
  is_active boolean not null default true,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table keyword_groups (
  id uuid primary key default gen_random_uuid(),
  workspace_id uuid not null references workspaces(id) on delete cascade,
  topic_id uuid references topics(id) on delete cascade,
  name text not null,
  positive_keywords jsonb not null default '[]'::jsonb,
  negative_keywords jsonb not null default '[]'::jsonb,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table source_connectors (
  id uuid primary key default gen_random_uuid(),
  workspace_id uuid not null references workspaces(id) on delete cascade,
  source_name text not null,
  connector_type text not null,
  status text not null default 'inactive',
  config_json jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table authors (
  id uuid primary key default gen_random_uuid(),
  workspace_id uuid not null references workspaces(id) on delete cascade,
  source_name text not null,
  external_author_id text,
  name text not null,
  profile_url text,
  headline text,
  company text,
  follower_count integer,
  activity_score numeric(6,2) default 0,
  relevance_score numeric(6,2) default 0,
  raw_json jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table posts (
  id uuid primary key default gen_random_uuid(),
  workspace_id uuid not null references workspaces(id) on delete cascade,
  source_name text not null,
  external_post_id text,
  author_id uuid references authors(id) on delete set null,
  post_url text not null,
  post_text text,
  published_at timestamptz,
  like_count integer default 0,
  comment_count integer default 0,
  repost_count integer default 0,
  engagement_score numeric(8,2) default 0,
  topic_score numeric(8,2) default 0,
  language text,
  raw_json jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table comments (
  id uuid primary key default gen_random_uuid(),
  workspace_id uuid not null references workspaces(id) on delete cascade,
  post_id uuid not null references posts(id) on delete cascade,
  author_id uuid references authors(id) on delete set null,
  external_comment_id text,
  comment_text text not null,
  published_at timestamptz,
  like_count integer default 0,
  sentiment text,
  intent_label text,
  raw_json jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table ai_drafts (
  id uuid primary key default gen_random_uuid(),
  workspace_id uuid not null references workspaces(id) on delete cascade,
  entity_type text not null,
  entity_id uuid not null,
  draft_type text not null,
  tone_preset text not null,
  length_pref text default 'medium',
  cta_pref text default 'none',
  option_1 text,
  option_2 text,
  option_3 text,
  selected_option integer,
  edited_text text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table engagement_actions (
  id uuid primary key default gen_random_uuid(),
  workspace_id uuid not null references workspaces(id) on delete cascade,
  user_id uuid not null,
  entity_type text not null,
  entity_id uuid not null,
  action_type text not null,
  action_mode text,
  final_text text,
  destination_url text,
  created_at timestamptz not null default now()
);
